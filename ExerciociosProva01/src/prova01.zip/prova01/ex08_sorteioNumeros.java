package prova01;

public class ex08_sorteioNumeros {

	public static void main(String[] args) {
		
		double rand = Math.round(Math.random() * 100);
	    
	    System.out.print("Número: " + rand);
	}

}


